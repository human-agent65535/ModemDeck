/*
 *  Copyright (c) 2018 The WebRTC project authors. All Rights Reserved.
 *
 *  Use of this source code is governed by a BSD-style license
 *  that can be found in the LICENSE file in the root of the source
 *  tree. An additional intellectual property rights grant can be found
 *  in the file PATENTS.  All contributing project authors may
 *  be found in the AUTHORS file in the root of the source tree.
 */

#include "api/transport/network_types.h"

#include <algorithm>
#include <vector>

#include "api/transport/ecn_marking.h"
#include "api/units/data_rate.h"
#include "api/units/time_delta.h"
#include "api/units/timestamp.h"

namespace webrtc {
StreamsConfig::StreamsConfig() = default;
StreamsConfig::StreamsConfig(const StreamsConfig&) = default;
StreamsConfig::~StreamsConfig() = default;

TargetRateConstraints::TargetRateConstraints() = default;
TargetRateConstraints::TargetRateConstraints(const TargetRateConstraints&) =
    default;
TargetRateConstraints::~TargetRateConstraints() = default;

NetworkRouteChange::NetworkRouteChange() = default;
NetworkRouteChange::NetworkRouteChange(const NetworkRouteChange&) = default;
NetworkRouteChange::~NetworkRouteChange() = default;

PacketResult::PacketResult() = default;
PacketResult::PacketResult(const PacketResult& other) = default;
PacketResult::~PacketResult() = default;

bool PacketResult::ReceiveTimeOrder::operator()(const PacketResult& lhs,
                                                const PacketResult& rhs) {
  if (lhs.receive_time != rhs.receive_time)
    return lhs.receive_time < rhs.receive_time;
  if (lhs.sent_packet.send_time != rhs.sent_packet.send_time)
    return lhs.sent_packet.send_time < rhs.sent_packet.send_time;
  return lhs.sent_packet.sequence_number < rhs.sent_packet.sequence_number;
}

TransportPacketsFeedback::TransportPacketsFeedback() = default;
TransportPacketsFeedback::TransportPacketsFeedback(
    const TransportPacketsFeedback& other) = default;
TransportPacketsFeedback::~TransportPacketsFeedback() = default;

std::vector<PacketResult> TransportPacketsFeedback::ReceivedWithSendInfo()
    const {
  std::vector<PacketResult> res;
  for (const PacketResult& fb : packet_feedbacks) {
    if (fb.IsReceived()) {
      res.push_back(fb);
    }
  }
  return res;
}

std::vector<PacketResult> TransportPacketsFeedback::LostWithSendInfo() const {
  std::vector<PacketResult> res;
  for (const PacketResult& fb : packet_feedbacks) {
    if (!fb.IsReceived()) {
      res.push_back(fb);
    }
  }
  return res;
}

std::vector<PacketResult> TransportPacketsFeedback::PacketsWithFeedback()
    const {
  return packet_feedbacks;
}

std::vector<PacketResult> TransportPacketsFeedback::SortedByReceiveTime()
    const {
  std::vector<PacketResult> res;
  for (const PacketResult& fb : packet_feedbacks) {
    if (fb.IsReceived()) {
      res.push_back(fb);
    }
  }
  std::sort(res.begin(), res.end(), PacketResult::ReceiveTimeOrder());
  return res;
}

NetworkControlUpdate::NetworkControlUpdate() = default;
NetworkControlUpdate::NetworkControlUpdate(const NetworkControlUpdate&) =
    default;
NetworkControlUpdate::~NetworkControlUpdate() = default;

PacedPacketInfo::PacedPacketInfo() = default;

PacedPacketInfo::PacedPacketInfo(int probe_cluster_id,
                                 int probe_cluster_min_probes,
                                 int probe_cluster_min_bytes)
    : probe_cluster_id(probe_cluster_id),
      probe_cluster_min_probes(probe_cluster_min_probes),
      probe_cluster_min_bytes(probe_cluster_min_bytes) {}

bool PacedPacketInfo::operator==(const PacedPacketInfo& rhs) const {
  return send_bitrate == rhs.send_bitrate &&
         probe_cluster_id == rhs.probe_cluster_id &&
         probe_cluster_min_probes == rhs.probe_cluster_min_probes &&
         probe_cluster_min_bytes == rhs.probe_cluster_min_bytes;
}

PacerConfig PacerConfig::Create(Timestamp at_time,
                                DataRate send_rate,
                                DataRate pad_rate,
                                TimeDelta time_window) {
  PacerConfig pacer_config;
  pacer_config.at_time = at_time;
  pacer_config.time_window = time_window;
  // Note that precision is lost here, since DataSize store number of bytes.
  pacer_config.data_window = send_rate * pacer_config.rate_window();
  pacer_config.pad_window = pad_rate * pacer_config.rate_window();
  return pacer_config;
}

bool TransportPacketsFeedback::HasPacketWithEcnCe() const {
  for (const PacketResult& fb : packet_feedbacks) {
    if (fb.ecn == EcnMarking::kCe) {
      return true;
    }
  }
  return false;
}

bool TransportPacketsFeedback::HasPacketWithBleachedEct1() const {
  for (const PacketResult& fb : packet_feedbacks) {
    // Only received packets say anything about what the path did to the
    // marking. Packets reported lost carry a defaulted Not-ECT marking and
    // would otherwise be indistinguishable from bleached ones. ECT(0) counts
    // as bleached since the path took the packet out of L4S.
    if (fb.sent_with_ect1 && fb.IsReceived() && fb.ecn != EcnMarking::kEct1 &&
        fb.ecn != EcnMarking::kCe) {
      return true;
    }
  }
  return false;
}

bool TransportPacketsFeedback::HasPacketWithEcn() const {
  for (const PacketResult& fb : packet_feedbacks) {
    // Only packets that were sent as ECT(1) say anything about what the path
    // did to the marking. Some networks set the ECN bits on packets that were
    // sent Not-ECT.
    if (fb.sent_with_ect1 && fb.IsReceived() &&
        (fb.ecn == EcnMarking::kEct1 || fb.ecn == EcnMarking::kCe)) {
      return true;
    }
  }
  return false;
}

}  // namespace webrtc
